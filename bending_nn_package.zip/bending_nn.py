"""Predict first-bending-mode fringe images of unknown vehicles from their pixels.

Neural network, training and inference are pure NumPy. Pillow is used only to read/write
PNGs and matplotlib only for the jet colour lookup table and the result figures.

Data (from make_dataset.py):
  dataset/train/<id>_{side,front}_geom.png  + _mode.png   (25 training vehicles)
  dataset/unknown/<id>_{side,front}_geom.png               (vehicles to predict)
  dataset/unknown_truth/...                                (optional, validation only)

Model = a coordinate MLP conditioned on a shape code:
  1. Each geometry image -> body/tyre pixel masks.
  2. Shape code per vehicle, computed only from pixels:
       PCA of down-sampled masks + pixel descriptors (length, height, width,
       axle positions from tyre pixels, roof-height profile at 6 interior stations).
  3. For every body pixel: [view, relative x, relative z, Fourier(x), shape code]
       -> MLP (tanh 96-96-64, sigmoid) -> normalised |u| at that pixel.
  4. Ridge regression on the shape code -> first bending frequency f1.
Targets are recovered from the training fringe images by inverting the jet colormap.
"""
import os, glob, csv, argparse
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import cm

JET = cm.jet(np.linspace(0, 1, 256))[:, :3]
PX_PER_M = 40.0

# ------------------------------------------------------------------ pixels
def read_rgb(path):
    return np.asarray(Image.open(path).convert("RGB"), dtype=np.float32) / 255.0

def masks(rgb):
    mx, mn = rgb.max(-1), rgb.min(-1)
    white = mn > 0.93
    tyre = (mx < 0.32) & (mx - mn < 0.06)
    body = ~white & ~tyre
    return body, tyre

def fringe_from_jet(rgb, body):
    """Invert the jet colormap: nearest LUT entry for every body pixel."""
    out = np.zeros(body.shape, np.float32)
    px = rgb[body]
    d = ((px[:, None, :] - JET[None]) ** 2).sum(-1)
    out[body] = d.argmin(1) / 255.0
    return out

def downsample(m, f=4):
    h, w = (m.shape[0] // f) * f, (m.shape[1] // f) * f
    return m[:h, :w].reshape(h // f, f, w // f, f).mean((1, 3))

def descriptors(side_body, side_tyre, front_body):
    H, W = side_body.shape
    cols = np.where(side_body.any(0))[0]; rows = np.where(side_body.any(1))[0]
    x0, x1 = cols.min(), cols.max(); L = (x1 - x0 + 1) / PX_PER_M
    height = (H - rows.min()) / PX_PER_M
    fcols = np.where(front_body.any(0))[0]; width = (fcols.max() - fcols.min() + 1) / PX_PER_M
    # axle positions from tyre pixel columns (two clusters)
    tc = np.where(side_tyre.any(0))[0]
    gap = np.argmax(np.diff(tc)) if len(tc) > 1 else 0
    ax_f = (tc[:gap + 1].mean() - x0) / (x1 - x0); ax_r = (tc[gap + 1:].mean() - x0) / (x1 - x0)
    # roof-height profile at 6 interior stations (relative to overall height)
    top = np.array([H - np.argmax(side_body[:, c]) if side_body[:, c].any() else 0 for c in range(W)])
    st = np.linspace(x0, x1, 8)[1:-1].astype(int)
    prof = top[st] / max(top.max(), 1)
    return np.concatenate([[L, height, width, ax_f, ax_r], prof]).astype(np.float32), (x0, x1, rows.min())

def load_vehicle(folder, vid, with_mode):
    d = {"id": vid}
    for view in ("side", "front"):
        rgb = read_rgb(f"{folder}/{vid}_{view}_geom.png")
        b, t = masks(rgb)
        d[view] = {"body": b, "tyre": t}
        if with_mode:
            mrgb = read_rgb(f"{folder}/{vid}_{view}_mode.png")
            mb, _ = masks(mrgb)
            d[view]["target"] = fringe_from_jet(mrgb, mb)
    d["desc"], d["bbox"] = descriptors(d["side"]["body"], d["side"]["tyre"], d["front"]["body"])
    d["raw"] = np.concatenate([downsample(d[v][k]).ravel() for v in ("side", "front") for k in ("body", "tyre")])
    return d

# ------------------------------------------------------------- shape code
class ShapeCoder:
    def __init__(self, n_pca=3): self.k = n_pca
    def fit(self, vehicles):
        R = np.stack([v["raw"] for v in vehicles]); self.mu = R.mean(0)
        _, S, Vt = np.linalg.svd(R - self.mu, full_matrices=False)
        self.P = Vt[:self.k]; self.ps = S[:self.k] / np.sqrt(len(R))
        F = np.stack([self._feat(v, raw=True) for v in vehicles])
        self.fm, self.fs = F.mean(0), F.std(0) + 1e-6
        return self
    def _feat(self, v, raw=False):
        pc = (v["raw"] - self.mu) @ self.P.T / self.ps
        return np.concatenate([pc, v["desc"]])
    def __call__(self, v): return (self._feat(v) - self.fm) / self.fs

# ---------------------------------------------------------- pixel features
NF = 5
def pixel_features(v, code, view):
    m = v[view]["body"]; r, c = np.nonzero(m)
    H = m.shape[0]
    rr, cc = np.where(m.any(1))[0], np.where(m.any(0))[0]
    if view == "side":
        x0, x1 = v["bbox"][0], v["bbox"][1]
        xr = (c - x0) / max(x1 - x0, 1)
    else:
        xr = (c - cc.min()) / max(cc.max() - cc.min(), 1)
    zr = (rr.max() - r) / max(rr.max() - rr.min(), 1)
    k = np.arange(1, NF + 1)
    four = np.concatenate([np.sin(np.pi * xr[:, None] * k), np.cos(np.pi * xr[:, None] * k)], 1)
    vflag = np.full((len(r), 1), 1.0 if view == "side" else -1.0)
    X = np.hstack([vflag, xr[:, None], zr[:, None], zr[:, None] * vflag, four,
                   np.repeat(code[None], len(r), 0)]).astype(np.float32)
    return X, (r, c)

# ------------------------------------------------------------- numpy MLP
class MLP:
    def __init__(self, sizes, seed=0):
        rng = np.random.default_rng(seed)
        self.W = [rng.normal(0, np.sqrt(1 / a), (a, b)).astype(np.float32) for a, b in zip(sizes[:-1], sizes[1:])]
        self.b = [np.zeros(b, np.float32) for b in sizes[1:]]
        self.m = [np.zeros_like(p) for p in self.W + self.b]; self.v = [np.zeros_like(p) for p in self.W + self.b]; self.t = 0
    def forward(self, X):
        self.a = [X]
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            z = self.a[-1] @ W + b
            self.a.append(np.tanh(z) if i < len(self.W) - 1 else 1 / (1 + np.exp(-z)))
        return self.a[-1][:, 0]
    def step(self, X, y, lr=2e-3, wd=1e-5):
        p = self.forward(X); n = len(y)
        g = ((p - y) * p * (1 - p) * 2 / n)[:, None]
        gW, gb = [], []
        for i in reversed(range(len(self.W))):
            gW.insert(0, self.a[i].T @ g + wd * self.W[i]); gb.insert(0, g.sum(0))
            if i: g = (g @ self.W[i].T) * (1 - self.a[i] ** 2)
        self.t += 1; b1, b2 = 0.9, 0.999
        for j, (P, G) in enumerate(zip(self.W + self.b, gW + gb)):
            self.m[j] = b1 * self.m[j] + (1 - b1) * G; self.v[j] = b2 * self.v[j] + (1 - b2) * G * G
            P -= lr * (self.m[j] / (1 - b1 ** self.t)) / (np.sqrt(self.v[j] / (1 - b2 ** self.t)) + 1e-8)
        return np.mean((p - y) ** 2)

# ------------------------------------------------------------- ridge (f1)
def ridge_fit(X, y, alphas=(0.1, 0.3, 1, 3, 10, 30)):
    Xb = np.hstack([X, np.ones((len(X), 1))]); best = None
    for a in alphas:                      # leave-one-out to pick alpha
        I = np.eye(Xb.shape[1]); I[-1, -1] = 0
        Hm = Xb @ np.linalg.solve(Xb.T @ Xb + a * I, Xb.T)
        loo = np.mean(((y - Hm @ y) / (1 - np.diag(Hm))) ** 2)
        if best is None or loo < best[0]: best = (loo, a)
    I = np.eye(Xb.shape[1]); I[-1, -1] = 0
    w = np.linalg.solve(Xb.T @ Xb + best[1] * I, Xb.T @ y)
    return w, best

# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="dataset"); ap.add_argument("--out", default="predictions")
    ap.add_argument("--steps", type=int, default=6000); ap.add_argument("--batch", type=int, default=4096)
    ap.add_argument("--code_noise", type=float, default=0.35)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)

    ids = sorted({os.path.basename(p).split("_")[0] for p in glob.glob(f"{a.data}/train/*_side_geom.png")})
    train = [load_vehicle(f"{a.data}/train", i, True) for i in ids]
    labels = {r["id"]: float(r["f1_Hz"]) for r in csv.DictReader(open(f"{a.data}/train/labels.csv"))}
    uids = sorted({os.path.basename(p).split("_")[0] for p in glob.glob(f"{a.data}/unknown/*_side_geom.png")},
                  key=lambda s: int(s[1:]))
    has_truth = os.path.isdir(f"{a.data}/unknown_truth")
    unknown = [load_vehicle(f"{a.data}/unknown", i, False) for i in uids]
    if has_truth:
        for u in unknown:
            for view in ("side", "front"):
                rgb = read_rgb(f"{a.data}/unknown_truth/{u['id']}_{view}_mode.png")
                u[view]["target"] = fringe_from_jet(rgb, masks(rgb)[0])
        tlabels = {r["id"]: float(r["f1_Hz"]) for r in csv.DictReader(open(f"{a.data}/unknown_truth/labels.csv"))}
    print(f"training vehicles: {len(train)}   unknown: {len(unknown)}")

    coder = ShapeCoder().fit(train)
    Xs, ys = [], []
    for v in train:
        code = coder(v)
        for view in ("side", "front"):
            X, (r, c) = pixel_features(v, code, view)
            Xs.append(X); ys.append(v[view]["target"][r, c])
    X = np.vstack(Xs); y = np.concatenate(ys).astype(np.float32)
    print(f"training pixels: {len(y):,}   features/pixel: {X.shape[1]}")

    ncode = len(coder(train[0]))
    net = MLP([X.shape[1], 96, 96, 64, 1], seed=1)
    rng = np.random.default_rng(0); hist = []
    for s in range(1, a.steps + 1):
        idx = rng.integers(0, len(y), a.batch)
        Xb = X[idx].copy()
        veh_noise = rng.normal(0, a.code_noise, (a.batch, ncode)).astype(np.float32)
        Xb[:, -ncode:] += veh_noise
        lr = 3e-3 * (0.5 * (1 + np.cos(np.pi * s / a.steps))) + 1e-4
        hist.append(net.step(Xb, y[idx], lr=lr, wd=1e-4))
        if s % 1000 == 0: print(f"  step {s:5d}  mse {np.mean(hist[-200:]):.5f}")

    # frequency head
    C = np.stack([coder(v) for v in train]); f = np.array([labels[v["id"]] for v in train])
    wf, (loo, alpha) = ridge_fit(C, f)
    print(f"f1 ridge: alpha={alpha}, leave-one-out RMSE={np.sqrt(loo):.2f} Hz")

    # ------------------------------------------------ predict unknown vehicles
    results = []
    for u in unknown:
        code = coder(u); res = {"id": u["id"]}
        res["f1"] = float(np.append(code, 1) @ wf)
        for view in ("side", "front"):
            Xu, (r, c) = pixel_features(u, code, view)
            pred = np.full(u[view]["body"].shape, np.nan, np.float32); pred[r, c] = net.forward(Xu)
            res[view] = pred
            img = np.ones(pred.shape + (3,), np.float32)
            img[r, c] = JET[np.clip((pred[r, c] * 255).round().astype(int), 0, 255)]
            img[u[view]["tyre"]] = 0.2
            Image.fromarray((img * 255).astype(np.uint8)).save(f"{a.out}/{u['id']}_{view}_mode_pred.png")
            if has_truth:
                t = u[view]["target"]; res[f"{view}_mae"] = float(np.mean(np.abs(pred[r, c] - t[r, c])))
        if has_truth: res["f1_true"] = tlabels[u["id"]]
        results.append(res)
        msg = f"{u['id']}: f1_pred={res['f1']:.1f} Hz"
        if has_truth:
            msg += f"  (true {res['f1_true']:.1f})  pixel MAE side={res['side_mae']:.3f} front={res['front_mae']:.3f}"
        print(msg)

    # ------------------------------------------------ figures
    ncol = 4 if has_truth else 2
    for u, res in zip(unknown, results):
        fig, axs = plt.subplots(2, ncol, figsize=(4.2 * ncol, 5.2), dpi=130,
                                gridspec_kw={"width_ratios": [1] * ncol})
        for row, view in enumerate(("side", "front")):
            geo = read_rgb(f"{a.data}/unknown/{u['id']}_{view}_geom.png")
            panels = [("Input image", geo, None), ("NN prediction", res[view], cm.jet)]
            if has_truth:
                t = np.where(u[view]["body"], u[view]["target"], np.nan)
                panels += [("Beam-model truth", t, cm.jet), ("|error|", np.abs(res[view] - t), cm.magma_r)]
            for col, (title, im, cmap) in enumerate(panels):
                ax = axs[row, col]
                if cmap is None: ax.imshow(im)
                else:
                    cmo = cmap.copy(); cmo.set_bad("white")
                    hnd = ax.imshow(im, cmap=cmo, vmin=0, vmax=1 if "error" not in title else 0.3)
                    tyre = np.ma.masked_where(~u[view]["tyre"], np.ones_like(im))
                    ax.imshow(tyre, cmap="gray", vmin=0, vmax=5)
                ax.set_title(f"{title} — {view}", fontsize=9); ax.axis("off")
        sub = f"predicted f₁ ≈ {res['f1']:.1f} Hz"
        if has_truth:
            sub += f"  (truth {res['f1_true']:.1f} Hz)   pixel MAE: side {res['side_mae']:.3f}, front {res['front_mae']:.3f}"
        fig.suptitle(f"{u['id']} — first bending mode predicted from pixels\n{sub}", fontsize=11)
        fig.tight_layout(); fig.savefig(f"{a.out}/{u['id']}_comparison.png", facecolor="white"); plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 3.2), dpi=130)
    ax.plot(np.convolve(hist, np.ones(100) / 100, "valid")); ax.set_yscale("log")
    ax.set_xlabel("step"); ax.set_ylabel("pixel MSE (train)"); ax.set_title("Training loss")
    fig.tight_layout(); fig.savefig(f"{a.out}/training_loss.png"); plt.close(fig)

    with open(f"{a.out}/predictions.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "f1_pred_Hz"] + (["f1_true_Hz", "side_MAE", "front_MAE"] if has_truth else []))
        for r in results:
            w.writerow([r["id"], round(r["f1"], 2)] +
                       ([r["f1_true"], round(r["side_mae"], 4), round(r["front_mae"], 4)] if has_truth else []))
    np.savez(f"{a.out}/model.npz", *net.W, *net.b, wf=wf)

if __name__ == "__main__":
    main()
