"""Build a paired image dataset for learning bending-mode fringes from vehicle pixels.

dataset/train/<id>_{side,front}_geom.png   plain silhouette (input)
dataset/train/<id>_{side,front}_mode.png   jet fringe of |u|/|u|max on undeformed body (target)
dataset/train/labels.csv                   id, f1_Hz
dataset/unknown/<U#>_{side,front}_geom.png inputs to predict (U6..U10)
dataset/unknown_truth/...                  beam-model truth, used only for validation

All images share one fixed metric framing (40 px/m) so absolute size is encoded in pixels.
"""
import os, csv, numpy as np
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "bending_modes.py")).read()
ns = {}; exec(src[:src.index("catcol =")], ns)
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from matplotlib import cm, colors as mcolors

V, first_bending, surface_quads = ns["V"], ns["first_bending"], ns["surface_quads"]
PX_PER_M = 40
SIDE_X, FRONT_Y, ZLIM = (-0.3, 7.9), (-1.4, 1.4), (-0.05, 3.45)

def canvas(xlim):
    w = int(round((xlim[1] - xlim[0]) * PX_PER_M)); h = int(round((ZLIM[1] - ZLIM[0]) * PX_PER_M))
    fig = plt.figure(figsize=(w / 100, h / 100), dpi=100)
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(*xlim); ax.set_ylim(*ZLIM); ax.axis("off")
    return fig, ax

def render(v, view, mode, color="0.55", fn=None):
    Q, val, _ = surface_quads(v, 0.0)
    n = np.cross(Q[:, 2] - Q[:, 0], Q[:, 3] - Q[:, 1])
    vd = np.array([0, -1, 0]) if view == "side" else np.array([-1, 0, 0])
    if view == "side": h, depth = Q[..., 0], Q[..., 1].mean(1)
    else:              h, depth = -Q[..., 1], Q[..., 0].mean(1)
    n = np.where((n @ vd)[:, None] < 0, -n, n)
    order = np.argsort(-depth); order = order[((n @ vd) > 1e-9)[order]]
    fc = cm.jet(np.clip(val, 0, 1)) if mode else np.tile(mcolors.to_rgba(color), (len(val), 1))
    fig, ax = canvas(SIDE_X if view == "side" else FRONT_Y)
    L, W, H = v["L"], v["W"], v["H"]
    r = 0.31 if H < 1.6 else 0.37 if H < 2.1 else 0.42
    t = np.linspace(0, 2 * np.pi, 48); tire = (0.2, 0.2, 0.2)
    if view == "front":
        for s in (-1, 1):
            yw = s * 0.5 * W * 0.86
            ax.fill(-(yw + np.array([-.13, .13, .13, -.13])), [0, 0, 2 * r, 2 * r], color=tire, lw=0, antialiased=False)
    ax.add_collection(PolyCollection(np.stack([h, Q[..., 2]], -1)[order], facecolors=fc[order],
                                     edgecolors=fc[order], linewidths=0.3, antialiaseds=False))
    if view == "side":
        for xa in v["axles"]:
            ax.fill(xa * L + r * np.cos(t), r + r * np.sin(t), color=tire, lw=0, antialiased=False)
    fig.savefig(fn, dpi=100, facecolor="white"); plt.close(fig)

# --- blend generator (mirrors hybrid_modes.py / plain_vehicles.py random sequences)
base = {"Sedan": (ns["sedan"], 4.90, 1.84, 1.45, 1.35e7, 290),
        "Van":   (ns["cargo_van"], 5.60, 2.02, 2.30, 1.15e7, 370),
        "Truck": (ns["pickup_crew"], 5.90, 2.03, 1.95, 1.05e7, 380)}
xs = np.linspace(0, 1, 121)
def zprof(p):
    px, pz = np.array(p).T
    return np.interp(xs, px + np.arange(len(px)) * 1e-6, pz)

def blend(rng, name, hybrid_style):
    ws = dict(zip(base, rng.dirichlet([1.2, 1.2, 1.2])))
    H = sum(ws[n] * base[n][3] for n in base)
    z = sum(ws[n] * zprof(base[n][0]) * base[n][3] for n in base) / H
    L = sum(ws[n] * base[n][1] for n in base) * rng.uniform(0.95, 1.05)
    W = sum(ws[n] * base[n][2] for n in base)
    EI = np.exp(sum(ws[n] * np.log(base[n][4]) for n in base))
    if hybrid_style: EI *= rng.uniform(0.9, 1.1)
    mpl = sum(ws[n] * base[n][5] for n in base)
    axles = (round(rng.uniform(.14, .18), 3), round(rng.uniform(.75, .80), 3))
    lumps = [(0.10, 200 + 150 * ws["Truck"] + 60 * ws["Van"])]
    if hybrid_style and rng.random() < 0.5: lumps.append((0.48, rng.uniform(80, 300)))
    return V(name, "Hybrid", L, W, H, list(zip(xs, z)), axles, EI, mpl, lumps,
             frame=ws["Truck"] > 0.40, soft=(0.565,) if ws["Truck"] > 0.30 else ())

if __name__ == "__main__":
    root = "dataset"
    for d in ("train", "unknown", "unknown_truth"): os.makedirs(os.path.join(root, d), exist_ok=True)
    train = [(f"V{k+1:02d}", v) for k, v in enumerate(ns["vehicles"])]
    rng = np.random.default_rng(2026)
    train += [(f"U{k+1}", blend(rng, f"U{k+1}", True)) for k in range(5)]
    rng = np.random.default_rng(7)
    unknown = [(f"U{k+6}", blend(rng, f"U{k+6}", False)) for k in range(5)]
    palette = ["#2E6FB7", "#C0392B", "#2E8B57", "#D68910", "#7D3C98"]

    rows = []
    for vid, v in train:
        v["mode"] = first_bending(v)
        for view in ("side", "front"):
            render(v, view, False, fn=f"{root}/train/{vid}_{view}_geom.png")
            render(v, view, True, fn=f"{root}/train/{vid}_{view}_mode.png")
        rows.append((vid, v["name"], round(v["mode"][2], 3)))
    with open(f"{root}/train/labels.csv", "w", newline="") as f:
        csv.writer(f).writerows([("id", "name", "f1_Hz")] + rows)

    rows = []
    for k, (vid, v) in enumerate(unknown):
        v["mode"] = first_bending(v)
        for view in ("side", "front"):
            render(v, view, False, color=palette[k], fn=f"{root}/unknown/{vid}_{view}_geom.png")
            render(v, view, True, fn=f"{root}/unknown_truth/{vid}_{view}_mode.png")
        rows.append((vid, v["name"], round(v["mode"][2], 3)))
    with open(f"{root}/unknown_truth/labels.csv", "w", newline="") as f:
        csv.writer(f).writerows([("id", "name", "f1_Hz")] + rows)
    print(f"train: {len(train)} vehicles, unknown: {len(unknown)}")
