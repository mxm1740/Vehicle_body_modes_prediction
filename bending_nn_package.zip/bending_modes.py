"""First vertical bending mode fringe plots for 20 parametric vehicles.

Each vehicle: lofted 3D body surface + 1D Timoshenko-free Euler-Bernoulli
free-free beam with section-dependent EI(x), m(x) and lumped masses.
First flexible eigenmode (after 2 rigid-body modes) is mapped onto the
surface; fringe = normalized displacement magnitude.
"""
import numpy as np
from scipy.linalg import eigh
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib import cm, colors

# ---------------------------------------------------------------- vehicles
# profile: list of (x_frac, z_top[m]) for roofline/top; bottom z, width,
# wheelbase frac positions, EI scale, structure type, lumped masses
def V(name, cat, L, W, H, prof, axles, EI, mpl, lumps, frame=False, soft=()):
    return dict(name=name, cat=cat, L=L, W=W, H=H, prof=prof, axles=axles,
                EI=EI, mpl=mpl, lumps=lumps, frame=frame, soft=soft)

# profile points (x/L, z/H)
sedan = [(0, .45), (.03, .55), (.25, .62), (.33, .66), (.45, 1.0), (.68, 1.0),
         (.82, .72), (.97, .68), (1, .55)]
coupe = [(0, .42), (.03, .52), (.28, .60), (.36, .64), (.50, 1.0), (.62, .98),
         (.84, .70), (.97, .66), (1, .52)]
hatch = [(0, .46), (.03, .57), (.22, .63), (.31, .68), (.45, 1.0), (.80, .98),
         (.93, .80), (.99, .62), (1, .5)]
wagon = [(0, .45), (.03, .55), (.24, .62), (.32, .66), (.44, 1.0), (.90, .98),
         (.97, .88), (1, .6)]
suv = [(0, .52), (.03, .66), (.20, .72), (.28, .76), (.38, 1.0), (.92, .98),
       (.98, .92), (1, .62)]
boxy = [(0, .55), (.02, .70), (.18, .74), (.24, .78), (.30, 1.0), (.97, 1.0),
        (1, .95), (1, .6)]
pickup_crew = [(0, .55), (.02, .68), (.20, .72), (.26, .75), (.36, 1.0), (.56, 1.0),
               (.565, .72), (.98, .72), (1, .70)]
pickup_reg = [(0, .55), (.02, .68), (.22, .72), (.28, .75), (.36, 1.0), (.47, 1.0),
              (.475, .72), (.98, .72), (1, .70)]
minivan = [(0, .45), (.03, .58), (.14, .64), (.24, .90), (.32, 1.0), (.94, .98),
           (.99, .85), (1, .55)]
cargo_van = [(0, .40), (.03, .55), (.12, .60), (.20, .92), (.26, 1.0), (.99, 1.0),
             (1, .5)]
box_truck = [(0, .40), (.02, .55), (.16, .58), (.20, .62), (.22, .72), (.255, .72),
             (.26, 1.0), (.99, 1.0), (1, .45)]

vehicles = [
    # Sedans / passenger cars  (EI N*m^2, mass/len kg/m, lumps (x/L, kg))
    V("Compact sedan", "Sedan", 4.55, 1.78, 1.44, sedan, (.17, .78), 1.15e7, 260, [(.10, 180), (.45, 80)]),
    V("Mid-size sedan", "Sedan", 4.90, 1.84, 1.45, sedan, (.17, .79), 1.35e7, 290, [(.10, 210), (.48, 90)]),
    V("Full-size luxury sedan", "Sedan", 5.25, 1.90, 1.48, sedan, (.16, .80), 1.60e7, 320, [(.10, 250), (.50, 110)]),
    V("Sports coupe", "Sedan", 4.70, 1.88, 1.30, coupe, (.16, .78), 1.70e7, 270, [(.11, 220)]),
    V("EV sedan (skateboard)", "Sedan", 4.80, 1.85, 1.44, sedan, (.17, .80), 1.90e7, 260, [(.48, 480), (.82, 110)]),
    V("Hatchback", "Sedan", 4.30, 1.80, 1.46, hatch, (.17, .80), 1.05e7, 250, [(.10, 170)]),
    V("Estate wagon", "Sedan", 4.95, 1.85, 1.50, wagon, (.17, .78), 1.20e7, 285, [(.10, 210)]),
    # SUVs
    V("Compact crossover", "SUV", 4.50, 1.85, 1.67, suv, (.17, .79), 1.25e7, 300, [(.10, 190)]),
    V("Mid-size 3-row SUV", "SUV", 5.00, 1.98, 1.78, suv, (.17, .79), 1.45e7, 340, [(.10, 240), (.75, 60)]),
    V("Full-size BoF SUV", "SUV", 5.35, 2.06, 1.94, suv, (.17, .78), 1.05e7, 420, [(.10, 320), (.55, 120)], frame=True),
    V("Boxy off-roader", "SUV", 4.75, 1.98, 1.97, boxy, (.17, .80), 0.95e7, 400, [(.10, 300), (.97, 45)], frame=True),
    # Pickups / trucks
    V("Mid-size pickup (crew)", "Truck", 5.40, 1.90, 1.85, pickup_crew, (.16, .76), 0.85e7, 330, [(.10, 270)], frame=True, soft=(.565,)),
    V("Full-size pickup (crew)", "Truck", 5.90, 2.03, 1.95, pickup_crew, (.15, .77), 1.05e7, 380, [(.10, 330)], frame=True, soft=(.565,)),
    V("HD pickup (crew)", "Truck", 6.25, 2.08, 2.03, pickup_crew, (.15, .78), 1.40e7, 450, [(.09, 450)], frame=True, soft=(.565,)),
    V("Regular-cab long bed", "Truck", 5.80, 2.03, 1.92, pickup_reg, (.15, .79), 1.00e7, 330, [(.09, 320)], frame=True, soft=(.475,)),
    V("Box truck (Class 4)", "Truck", 7.60, 2.30, 3.20, box_truck, (.13, .68), 2.40e7, 520, [(.07, 500), (.60, 300)], frame=True, soft=(.258,)),
    # Vans
    V("Minivan", "Van", 5.15, 2.00, 1.78, minivan, (.17, .80), 1.20e7, 330, [(.10, 230), (.70, 70)]),
    V("Compact cargo van", "Van", 4.70, 1.85, 1.85, cargo_van, (.15, .80), 1.00e7, 300, [(.08, 210)]),
    V("Full-size high-roof van", "Van", 5.95, 2.05, 2.75, cargo_van, (.13, .74), 1.15e7, 380, [(.07, 280)]),
    V("Passenger van (15-seat)", "Van", 6.40, 2.05, 2.30, cargo_van, (.13, .76), 1.25e7, 420, [(.07, 290), (.55, 200)]),
]
assert len(vehicles) == 20

# ------------------------------------------------------------- beam solver
def first_bending(v, ne=120):
    L = v["L"]
    x = np.linspace(0, L, ne + 1)
    xm = 0.5 * (x[:-1] + x[1:]) / L
    EI = np.full(ne, v["EI"])
    # stiffness loss at overhangs (crush rails) and at door/greenhouse openings
    EI *= np.where((xm < v["axles"][0] - .02) | (xm > v["axles"][1] + .06), 0.6, 1.0)
    if not v["frame"]:
        EI *= 1 - 0.25 * np.exp(-((xm - 0.48) / 0.12) ** 2)   # B-pillar/door opening
    for s in v["soft"]:                                       # cab-to-bed/box joint
        EI *= 1 - 0.55 * np.exp(-((xm - s) / 0.025) ** 2)
    m = np.full(ne, v["mpl"])
    nd = 2 * (ne + 1)
    K = np.zeros((nd, nd)); M = np.zeros((nd, nd))
    for e in range(ne):
        le = x[e + 1] - x[e]
        k = EI[e] / le**3 * np.array([[12, 6*le, -12, 6*le], [6*le, 4*le**2, -6*le, 2*le**2],
                                      [-12, -6*le, 12, -6*le], [6*le, 2*le**2, -6*le, 4*le**2]])
        mm = m[e] * le / 420 * np.array([[156, 22*le, 54, -13*le], [22*le, 4*le**2, 13*le, -3*le**2],
                                         [54, 13*le, 156, -22*le], [-13*le, -3*le**2, -22*le, 4*le**2]])
        idx = [2*e, 2*e+1, 2*e+2, 2*e+3]
        K[np.ix_(idx, idx)] += k; M[np.ix_(idx, idx)] += mm
    for xf, mass in v["lumps"]:
        n = int(round(xf * ne)); M[2*n, 2*n] += mass
    w2, phi = eigh(K, M)
    i = 2  # skip 2 rigid modes
    f = np.sqrt(max(w2[i], 0)) / (2*np.pi)
    wz = phi[0::2, i]
    wz /= np.max(np.abs(wz))
    if wz[0] < 0: wz = -wz
    return x, wz, f

# ------------------------------------------------------------- body mesh
def body_mesh(v, nx=70, nth=36):
    L, W, H = v["L"], v["W"], v["H"]
    px, pz = np.array(v["prof"]).T
    xs = np.linspace(0, 1, nx)
    # interpolate top: handle duplicate x by tiny offsets
    pxu = px + np.arange(len(px)) * 1e-6
    zt = np.interp(xs, pxu, pz) * H
    zb = np.full(nx, 0.16 * H if H < 2.5 else 0.20 * H)
    zb = np.minimum(zb, zt - 0.2)
    # end taper in plan view
    wfac = 1 - 0.10 * (np.clip(0.05 - xs, 0, None) / .05) ** 2 - 0.10 * (np.clip(xs - .95, 0, None) / .05) ** 2
    th = np.linspace(0, 2*np.pi, nth)
    X = np.zeros((nx, nth)); Y = np.zeros((nx, nth)); Z = np.zeros((nx, nth))
    belt = np.interp(xs, pxu, np.minimum(pz, 0.70 if H < 2.5 else 0.62)) * H
    for i, xf in enumerate(xs):
        c, s = np.cos(th), np.sin(th)
        n = 6.0
        yy = np.sign(c) * np.abs(c) ** (2/n)
        zz = np.sign(s) * np.abs(s) ** (2/n)
        zc = 0.5 * (zt[i] + zb[i]); hz = 0.5 * (zt[i] - zb[i])
        z = zc + hz * zz
        # tumblehome above beltline
        tum = np.where(z > belt[i], 1 - 0.18 * (z - belt[i]) / max(zt[i] - belt[i], 1e-3), 1.0)
        X[i] = xf * L
        Y[i] = 0.5 * W * wfac[i] * yy * tum
        Z[i] = z
    return X, Y, Z

def wheels(v, nth=40):
    L, H = v["L"], v["H"]
    r = 0.36 if H < 1.7 else 0.40 if H < 2.1 else 0.44
    out = []
    for a in v["axles"]:
        out.append((a * L, r))
    return out

# ------------------------------------------------------------- rendering
from matplotlib.collections import PolyCollection
cmap = cm.jet
norm = colors.Normalize(0, 1)
LIGHT = np.array([-0.45, -0.55, 0.70]); LIGHT /= np.linalg.norm(LIGHT)

def surface_quads(v, amp):
    x1d, wz, f = v["mode"]
    X, Y, Z = body_mesh(v)
    d = np.interp(X, x1d, wz)
    Zd = Z + amp * d
    P = np.stack([X, Y, Zd], -1)
    nx, nth = X.shape
    quads, vals = [], []
    for i in range(nx - 1):
        for j in range(nth - 1):
            quads.append([P[i, j], P[i+1, j], P[i+1, j+1], P[i, j+1]])
            vals.append(np.abs(d[i:i+2, j:j+2]).mean())
    # end caps (front x=0, rear x=L) as triangle fans
    for i in (0, nx - 1):
        c = P[i].mean(0)
        for j in range(nth - 1):
            quads.append([c, P[i, j], P[i, j+1], P[i, j+1]])
            vals.append(abs(d[i, 0]))
    return np.array(quads), np.array(vals), (X, Y, Z, Zd)

def render(ax, v, view):
    x1d, wz, f = v["mode"]
    L, W, H = v["L"], v["W"], v["H"]
    amp = 0.06 * H
    Q, val, (X, Y, Z, Zd) = surface_quads(v, amp)
    n = np.cross(Q[:, 2] - Q[:, 0], Q[:, 3] - Q[:, 1])
    nn = np.linalg.norm(n, axis=1); nn[nn == 0] = 1; n /= nn[:, None]
    if view == "side":       # viewer at -y looking +y
        vd = np.array([0, -1, 0]); h, depth = Q[..., 0], Q[..., 1].mean(1)
    else:                    # viewer at -x (car front) looking +x
        vd = np.array([-1, 0, 0]); h, depth = -Q[..., 1], Q[..., 0].mean(1)
    n = np.where((n @ vd)[:, None] < 0, -n, n)        # flip normals toward viewer
    vis = (n @ vd) > 1e-3
    shade = 0.62 + 0.38 * np.clip(n @ LIGHT * -1 * -1, 0, 1)
    shade = 0.70 + 0.30 * np.clip(np.abs(n @ LIGHT), 0, 1)
    order = np.argsort(-depth)
    order = order[vis[order]]
    rgba = cmap(norm(val))
    rgba[:, :3] *= shade[:, None]
    verts = np.stack([h, Q[..., 2]], -1)
    t = np.linspace(0, 2*np.pi, 48)
    r = 0.31 if H < 1.6 else 0.37 if H < 2.1 else 0.42
    def tires(alpha_front):
        for xa in v["axles"]:
            dz = amp * np.interp(xa * L, x1d, wz)
            if view == "side":
                ax.fill(xa*L + r*np.cos(t), r + dz + r*np.sin(t), color="0.12", zorder=alpha_front)
                ax.fill(xa*L + .55*r*np.cos(t), r + dz + .55*r*np.sin(t), color="0.55", zorder=alpha_front)
            else:
                for s in (-1, 1):
                    yw = s * 0.5 * W * 0.86
                    ax.fill(-(yw + np.array([-.13, .13, .13, -.13])), dz + np.array([0, 0, 2*r, 2*r]),
                            color="0.12", zorder=alpha_front)
    if view == "front":
        tires(1)
    ax.add_collection(PolyCollection(verts[order], facecolors=rgba[order], edgecolors=rgba[order],
                                     linewidths=0.25, zorder=2))
    if view == "side":
        tires(3)
        # undeformed silhouette
        ax.plot(X[:, 0], Z.max(1), "k--", lw=0.7, alpha=.55, zorder=4)
        ax.plot(X[:, 0], Z.min(1), "k--", lw=0.7, alpha=.55, zorder=4)
        # nodal points of the mode
        zc = np.where(np.diff(np.sign(wz)) != 0)[0]
        for k in zc:
            xn = x1d[k] - wz[k] * (x1d[k+1] - x1d[k]) / (wz[k+1] - wz[k])
            ax.plot(xn, -0.12, marker="^", ms=8, color="k", zorder=5)
            ax.text(xn, -0.32, f"node {xn/L:.0%}L", ha="center", fontsize=7.5, color="0.25")
        ax.set_xlim(-0.25, L + 0.25); ax.set_ylim(-0.45, H + 0.35)
    else:
        ys = -Y; zmax = Zd.max()
        ax.set_xlim(-W/2 - .35, W/2 + .35); ax.set_ylim(-0.45, H + 0.35)
        # undeformed front silhouette
        ax.plot(-Y[0], Z[0], "k--", lw=0.7, alpha=.55, zorder=4)
    ax.set_aspect("equal"); ax.axis("off")

for v in vehicles:
    v["mode"] = first_bending(v)

catcol = {"Sedan": "#1f4e79", "SUV": "#8a4500", "Truck": "#5b2a86", "Van": "#1d6b3a"}
fig = plt.figure(figsize=(22, 46), dpi=120)
rows, cols = 10, 2
gs = fig.add_gridspec(rows, cols * 2, width_ratios=[3.3, 1.25] * cols, hspace=0.32, wspace=0.04,
                      left=0.015, right=0.985, top=0.958, bottom=0.03)
for k, v in enumerate(vehicles):
    r, c = k // cols, k % cols
    ax1 = fig.add_subplot(gs[r, 2*c]); ax2 = fig.add_subplot(gs[r, 2*c + 1])
    render(ax1, v, "side"); render(ax2, v, "front")
    f = v["mode"][2]
    ax1.set_title(f"{k+1:02d}. {v['name']}  ·  {v['cat']}  ·  f₁ ≈ {f:.1f} Hz",
                  fontsize=13, color=catcol[v["cat"]], loc="left", fontweight="bold")
    ax2.set_title(f"L {v['L']:.2f} · W {v['W']:.2f} · H {v['H']:.2f} m\n{'body-on-frame' if v['frame'] else 'unibody'}",
                  fontsize=8.5, color="0.4", loc="right")
    ax1.text(0.0, -0.02, "LATERAL VIEW", transform=ax1.transAxes, fontsize=7.5, color="0.5", va="top")
    ax2.text(0.5, -0.02, "FRONT VIEW", transform=ax2.transAxes, fontsize=7.5, color="0.5", ha="center", va="top")

fig.suptitle("First Global Vertical Bending Mode — Displacement-Magnitude Fringe, 20 Vehicles",
             fontsize=22, fontweight="bold", y=0.988)
fig.text(0.5, 0.972, "Parametric body surfaces + free-free Euler–Bernoulli beam (section-varying EI, distributed + lumped masses: powertrain, battery, payload box).  "
         "Deformation exaggerated; dashed = undeformed;  ▲ = nodal points.  Frequencies are indicative, not from production FE models.",
         ha="center", fontsize=11, color="0.3", wrap=True)
cax = fig.add_axes([0.32, 0.013, 0.36, 0.006])
cb = fig.colorbar(cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax, orientation="horizontal")
cb.set_label("Normalized displacement magnitude  |u| / |u|max", fontsize=12)
fig.savefig("first_bending_mode_20_vehicles.png", dpi=120, facecolor="white")
for k, v in enumerate(vehicles):
    print(f"{k+1:2d} {v['name']:28s} {v['mode'][2]:6.1f} Hz")
